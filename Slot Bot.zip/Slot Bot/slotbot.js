const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Events, ChannelType } = require('discord.js');
const fs = require('fs'); // Import fs to read/write files

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
    ],
});

const prefix = ',';
let cooldowns = new Map(); // For the ping cooldown
let blacklist = new Set(); // To hold blacklisted users

client.once(Events.ClientReady, () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

// Load data from data.json
let userData = {};
if (fs.existsSync('./data.json')) {
    userData = JSON.parse(fs.readFileSync('./data.json'));
}

client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot || !message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'shelp') {
        const helpEmbed = new EmbedBuilder()
            .setColor(0xffffff) // White color
            .setTitle('Slot Bot Commands')
            .setDescription('Here are the available commands:')
            .addFields(
                { name: ',create @user', value: 'Create a new slot for the mentioned user.' },
                { name: ',remove @user', value: 'Remove the mentioned user from their slot.' },
                { name: ',ping', value: 'Ping the @here role. (Cooldown: 10 hours)' },
                { name: ',blacklist @user', value: 'Blacklist a user from getting slots.' },
                { name: ',whitelist @user', value: 'Remove a user from the blacklist.' },
                { name: ',view_blacklist', value: 'View the blacklist of users.' }
            );
        await message.channel.send({ embeds: [helpEmbed] });
    }

    // Create command
    if (command === 'create') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.channel.send("You do not have permission to use this command.");
        }
    
        const user = message.mentions.users.first();
        if (!user) {
            return message.channel.send("Please mention a user to create a slot for.");
        }

        // Check if the user is blacklisted
        if (blacklist.has(user.id)) {
            return message.channel.send(`This user <@${user.id}> is blacklisted and cannot have a slot channel.`);
        }
    
        // Check if the channel already exists
        const existingChannel = message.guild.channels.cache.find(channel => channel.name === `slot-${user.username}`);
        if (existingChannel) {
            return message.channel.send(`A slot channel for ${user.username} already exists: ${existingChannel}.`);
        }
    
        // Create a new channel
        const channel = await message.guild.channels.create({
            name: `slot-${user.username}`, // Correctly set the channel name
            type: ChannelType.GuildText, // Use ChannelType for the channel type
            permissionOverwrites: [
                {
                    id: message.guild.id, // Default @everyone role
                    deny: [PermissionsBitField.Flags.ViewChannel],
                },
                {
                    id: user.id, // Allow the user to view their slot
                    allow: [PermissionsBitField.Flags.ViewChannel],
                },
            ],
        });
    
        // Create an embedded message
        const embed = new EmbedBuilder()
            .setColor('#FFFFFF') // Set the color to white
            .setTitle(`Slot Created for ${user.username}`)
            .setDescription(`Welcome to your slot, ${user.username}!\n\n**Rules:**\n- Follow Discord TOS.\n- Do not sell illegal items.`)
            .setTimestamp();
    
        // Send the embed message to the new channel
        await channel.send({ embeds: [embed] });
    
        // Notify the command user
        message.channel.send(`Slot created for ${user.username} in ${channel}.`);
    }

    // Remove command
    if (command === 'remove') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('You do not have permission to use this command.');
        }

        const user = message.mentions.users.first();
        if (!user) return message.reply('Please mention a user to remove from their slot.');

        // Check if the user is blacklisted
        if (blacklist.has(user.id)) {
            const blacklistEmbed = new EmbedBuilder()
                .setColor(0xff0000) // Red color
                .setDescription(`This <@${user.id}> is blacklisted and cannot have a slot channel.`);
            return await message.channel.send({ embeds: [blacklistEmbed] });
        }

        // Find the channel to delete
        const channel = message.guild.channels.cache.find(c => c.name === `slot-${user.username}`);
        if (channel) {
            await channel.delete(); // Delete the channel
            delete userData[user.id]; // Remove user data from userData object
            fs.writeFileSync('./data.json', JSON.stringify(userData)); // Save updated data to data.json
            const removeEmbed = new EmbedBuilder()
                .setColor(0xffffff) // White color
                .setDescription(`Slot removed for ${user.username}.`);
            await message.channel.send({ embeds: [removeEmbed] });
        } else {
            await message.channel.send(`No slot channel found for ${user.username}.`);
        }
    }

    // Ping command with cooldown
    if (command === 'ping') {
        const userId = message.author.id;

        // Check if user is on cooldown
        const cooldownAmount = 10 * 60 * 60 * 1000; // 10 hours in milliseconds
        const now = Date.now();

        if (cooldowns.has(userId) && now < cooldowns.get(userId) + cooldownAmount) {
            return message.reply('You can only ping once every 10 hours.');
        }

        cooldowns.set(userId, now); // Set the cooldown
        await message.channel.send('@here Ping!');
    }

    // Blacklist command
    if (command === 'blacklist') {
        const user = message.mentions.users.first();
        if (!user) return message.reply('Please mention a user to blacklist.');

        blacklist.add(user.id);
        await message.channel.send(`${user.username} has been blacklisted.`);
    }

    // Whitelist command
    if (command === 'whitelist') {
        const user = message.mentions.users.first();
        if (!user) return message.reply('Please mention a user to whitelist.');

        blacklist.delete(user.id);
        await message.channel.send(`${user.username} has been whitelisted.`);
    }

    // View blacklist command
    if (command === 'view_blacklist') {
        const blacklistedUsers = blacklist.size > 0 
            ? [...blacklist].map(id => `<@${id}>`).join(', ') 
            : 'No users are blacklisted.';
        
        const blacklistEmbed = new EmbedBuilder()
            .setColor(0xffffff) // White color
            .setDescription(`Blacklisted Users:\n${blacklistedUsers}`);
        await message.channel.send({ embeds: [blacklistEmbed] });
    }
});

client.login('MTI4OTI5NDExMzA1MjY5MjU1Mg.GQ85H1.5-I8AmMuqejwIVLb9qi3iMe4EqacKNSox3D_uA'); // Replace with your actual token
